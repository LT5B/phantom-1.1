#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

void execute_phantom(const char *cmd) {
    char *home = getenv("HOME");
    if (!home) {
        fprintf(stderr, "Phantom: HOME environment variable not found\n");
        return;
    }

    char target_cmd[1024];
    snprintf(target_cmd, sizeof(target_cmd), "%s/.phantom/main/%s", home, cmd);

    if (access(target_cmd, X_OK) == 0) {
        pid_t pid = fork();
        if (pid == 0) {
            execl(target_cmd, target_cmd, (char *)NULL);
            perror("Phantom: exec error");
            exit(EXIT_FAILURE);
        } else if (pid > 0) {
            wait(NULL);
        } else {
            perror("Phantom: fork error");
        }
    } else {
        printf("Phantom: Command not found: %s\n", cmd);
    }
}

int main(int argc, char *argv[]) {
    char cmd[256] = "";

    if (argc > 1) {
        for (int i = 1; i < argc; i++) {
            strcat(cmd, argv[i]);
            if (i < argc - 1) strcat(cmd, " ");
        }
        execute_phantom(cmd);
    } else {
        while (1) {
            printf("$ ");
            fflush(stdout);

            if (fgets(cmd, sizeof(cmd), stdin) == NULL) {
                break;
            }

            cmd[strcspn(cmd, "\n")] = 0;

            if (strlen(cmd) == 0) continue;

            execute_phantom(cmd);
        }
    }

    return 0;
}

